package com.example.Placement.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.example.Placement.entity.Admin;
import com.example.Placement.service.adminservice;




@RestController

public class adController {
	
@Autowired
public adminservice aser;

@PostMapping("/addad")
public Admin regadmin(@RequestBody Admin ad) {
	return aser.addadmin(ad);
	
}
@GetMapping("/getad")
public List<Admin> getad(){
	return aser.getadmin();
}
	
@DeleteMapping("/deletead/{id}")
public void deletead(@PathVariable Integer id) {
	aser.deleteadmin(id);
}
	
@PutMapping("/updatead")
public Admin updatead(@RequestBody Admin ad) {
	return aser.updateadmin(ad);
}
}
