package com.example.Placement.entity;

import jakarta.persistence.Entity;
import jakarta.persistence.Id;
import jakarta.persistence.Table;

@Entity
@Table
public class Admin {
	
	@Id
int adid;
String adname;
String adpass;
public int getAdid() {
	return adid;
}
public void setAdid(int adid) {
	this.adid = adid;
}
public String getAdname() {
	return adname;
}
public void setAdname(String adname) {
	this.adname = adname;
}
public String getAdpass() {
	return adpass;
}
public void setAdpass(String adpass) {
	this.adpass = adpass;
}

}
