package com.example.Placement.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.example.Placement.entity.Admin;

public interface adrepo extends JpaRepository<Admin,Integer> {

}
