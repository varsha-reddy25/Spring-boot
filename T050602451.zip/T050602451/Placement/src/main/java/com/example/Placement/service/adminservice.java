package com.example.Placement.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.Placement.entity.Admin;
import com.example.Placement.repository.adrepo;

@Service
public class adminservice {

@Autowired

public adrepo arepo;


public Admin addadmin(Admin ad) {
	return arepo.save(ad);
}


public List<Admin> getadmin(){
	return arepo.findAll();
}

public void deleteadmin(int id) {
	arepo.deleteById(id);
}

public Admin updateadmin(Admin ad) {
	Integer adid=ad.getAdid();
	Admin ad1=arepo.findById(adid).get();
	ad1.setAdname(ad.getAdname());
	return arepo.save(ad1);
	
}
	
}
